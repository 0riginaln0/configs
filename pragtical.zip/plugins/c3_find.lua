-- mod-version:3
local core = require "core"
local command = require "core.command"
local keymap = require "core.keymap"
local common = require "core.common"

-- TODO: ignore directories when searching
local include = {
  -- *.c3, *.c3i, ...
}
local exclude = {
  -- build
}
-- TODO: quick add std into project command

local function table_contains(t, element)
  for _, value in pairs(t) do
    if value == element then
      return true
    end
  end
  return false
end

--[[
```
 kwords   | naming               | surroundings
----------|----------------------|----------------------------------------
 fn macro | snake_case*          | 
 types    | PascalCase           | 
 modules  | snake_case           | `module` at the beginning of the line
 faultdef | SCREAMING_SNAKE_CASE | `~` after the word
 const    | SCREAMING_SNAKE_CASE | 
 method   | snake_case           | `.` before the word

*fn can also be camelCased
```
]]
local function identify_identifier(id)
  -- Basic validity checks
  if #id > 127 then
    core.log("C3 id can't be more than 127")
    return nil
  end
  if not id:match("^[A-Za-z0-9_]+$") then
    core.log("Identifier contains invalid characters")
    return nil
  end
  if id:match("^%d") then
    core.log("Identifier can't start with the digit")
    return nil
  end

  -- Find the first non-underscore character
  local first = id:match("^_*([A-Za-z0-9])")
  -- Only underscores (or empty) -> invalid
  if not first then
    if first == "" then
      core.log("Identifier can't be empty")
    else
      core.log("Identifier can't be only of underscores lol")
    end
    return nil
  end

  -- First non-underscore cannot be a digit
  if first:match("%d") then
    core.log("First non-underscore character can't be a digit")
    return nil
  end

  -- Classify based on first character and presence of lowercase letters
  if first:match("%l") then
    -- Starts with lowercase -> variable / parameter / function / macro
    -- I'm aware that at this point we also store camelCased ids as snake_case
    -- but it's ok since extern fns can be camselCased and so we will
    -- find it because of dispatching into fn_macro regex
    return "snake_case"
  elseif first:match("%u") then
   -- Starts with uppercase -> either type or constant
    if id:match("[a-z]") then
      -- Contains at least one lowercase -> type
      return "PascalCase"
    else
      -- No lowercase -> global constant / enum member / fault
      return "SCREAMING_SNAKE_CASE"
    end
  else
    core.log("Unknown identifier")
    return nil
  end
end


local function prefix_any_then_whole(word)    return   ".*\\b"..word.."\\b" end
local function prefix_spaces_then_whole(word) return "\\s+\\b"..word.."\\b" end

local things_i_can_find = {
  "fn", "macro", "struct", "union", "interface", "enum", "bitstruct",
  "alias", "typedef", "constdef", "module", "faultdef", "const",

  "method",
}

local type_things = {
  "struct", "union", "interface", "enum", "bitstruct", "alias", "typedef",
  "constdef",
}

local function regex_callable(word, kwds)
  local preprefix
  if not kwds then
    preprefix = "(fn |macro )"
  else
    preprefix = "("..table.concat(kwds, "|")..")"
  end

  return preprefix..prefix_any_then_whole(word)
end

local function regex_method(struct_name, method_name, kwds)
  local preprefix
  if not kwds then
    preprefix = "(fn |macro )"
  else
    preprefix = "("..table.concat(kwds, "| ")..")"
  end
  return preprefix..prefix_any_then_whole(struct_name.."."..method_name)
end

local function regex_types(word, kwds)
  local preprefix
  if not kwds then
    preprefix = "(struct|union|interface|enum|bitstruct|alias|typedef|constdef)"
  else
    preprefix = "("..table.concat(kwds, "|")..")"
  end
  return preprefix..prefix_spaces_then_whole(word)
end

local function regex_module(word)
  return "module "..prefix_any_then_whole(word).."(?!::).*;"
end

local function regex_faultdef(word)
  return "\\b"..word.."\\b(?=[,;])"
end

-- FIX:
--   this regex is false positive on `const bool LINUX = LIBC && OS_TYPE == LINUX;`
local function regex_const(word)
  return "const .*?\\b(?<!::)(?<!\\.)(?<!->)"..word.."\\b"
end


local function run_regex_query(regex_query)
  -- open global search
  command.perform "project-search:find"

  -- get a reference to the current view
  ---@type core.view | widget
  local current_view = core.active_view
  core.add_thread(function()
    -- wait until project search becomes active active
    while not current_view.parent do
      coroutine.yield()
      current_view = core.active_view
    end
    ---@type plugins.projectsearch.resultsview
    local search_view = current_view.parent -- this holds the ref to searchview
    search_view.regex_toggle:set_toggle(true)
    search_view.find_text:set_text(regex_query)
    search_view.sensitive_toggle:set_toggle(true)

    search_view:refresh()
    -- wait until there are search results.
    while search_view.searching do coroutine.yield() end

    -- select first result
    search_view:swap_active_child()
    search_view.results_list:select_next()
    search_view.results_list:select_next()

    if search_view.results_list.total_results == 1 then
      search_view:open_selected_result()
      -- close global search
      command.perform "project-search:find"
    end
  end)
end


local function get_identifier_under_cursor(dv)
  ---@cast dv core.docview
  command.perform "doc:select-word"
  local res = {}
  res.word = dv.doc:get_selection_text(1)

  local line1, col1, line2, col2 = dv.doc:get_selection(true)

  local line_text = dv.doc.lines[line1]
  local char_after = dv.doc:get_char(line2, col2)
  local char_before = dv.doc:get_char(line1, col1 - 1)
  if line_text:match("^%s*module ") or line_text:match("^%s*import ") then
    res.surroundings = "module"
  elseif char_after == "~" then
    res.surroundings = "faultdef"
  elseif char_before == "." then
    res.surroundings = "method"
  end

  local naming = identify_identifier(res.word)
  if naming then
    res.naming = naming
    return res
  end

  core.log("Failed to get identifier under cursor")
  return nil
end

local function handle_method_search(id)
  -- TODO: cache the results of searching or reuse the autocomplete plugin?
  local structs_in_current_doc = {}
  local doc = core.active_view.doc
  local symbol_pattern = doc:get_symbol_pattern()
  local seen = {}
  for i = 1, #doc.lines do
    for sym in doc.lines[i]:gmatch(symbol_pattern) do
      local naming = identify_identifier(sym)
      if naming == "PascalCase" and not seen[sym] then
        table.insert(structs_in_current_doc, sym)
        seen[sym] = true
      end
    end
  end

  core.command_view:enter("Struct Name", {
    submit = function(struct_text)
      if struct_text and #struct_text > 0 then
        run_regex_query(regex_method(struct_text, id.word))
      end
    end,
    suggest = function(text)
      local matched = common.fuzzy_match(structs_in_current_doc, text)
      local res = {}
      for i, name in ipairs(matched) do
        res[i] = { text = name }
      end
      return res
    end,
  })
end

local function find(dv)
  local id = get_identifier_under_cursor(dv)

  if not id then
    core.log("I don't know how to find `"..id.."`")
    return
  end

  if id.naming == "PascalCase" then
    run_regex_query(regex_types(id.word))
  elseif id.naming == "SCREAMING_SNAKE_CASE" and id.surroundings == "faultdef" then
    run_regex_query(regex_faultdef(id.word))
  elseif id.naming == "SCREAMING_SNAKE_CASE" then
    run_regex_query(regex_const(id.word))
  elseif id.naming == "snake_case" and id.surroundings == "method" then
    handle_method_search(id)
  elseif id.naming == "snake_case" and id.surroundings == "module" then
    run_regex_query(regex_module(id.word))
  elseif id.naming == "snake_case" then
    run_regex_query(regex_callable(id.word))
  else
    core.log("idk how to query for "..id.word)
  end
end

local function find_exactly(dv)
  local id = get_identifier_under_cursor(dv)

  if not id then
    core.log("I don't know how to find `"..id.."`")
    return
  end

  core.command_view:enter("What do you want to find?", {
    submit = function(wannafind)
      if not table_contains(things_i_can_find, wannafind) then
        core.log("I don't know how to find `"..wannafind.."`")
        return
      end
      if wannafind == "fn" then
        run_regex_query(regex_callable(id.word, {wannafind}))
      elseif wannafind == "macro" then
        run_regex_query(regex_callable(id.word, {wannafind}))
      elseif table_contains(type_things, wannafind) then
        run_regex_query(regex_types(id.word, {wannafind}))
      elseif wannafind == "module" then
        run_regex_query(regex_module(id.word))
      elseif wannafind == "faultdef" then
        run_regex_query(regex_faultdef(id.word))
      elseif wannafind == "const" then
        run_regex_query(regex_const(id.word))
      elseif wannafind == "method" then
        handle_method_search(id)
      else
        core.log("How did I end up like this?")
      end
    end,
    suggest = function(text)
      local matched = common.fuzzy_match(things_i_can_find, text)
      local res = {}
      for i, name in ipairs(matched) do
        res[i] = { text = name }
      end
      return res
    end,
  })
end


command.add("core.docview", {
  ["c3:find"] = find,
  ["c3:find_exactly"] = find_exactly,
})

keymap.add {
  ["f12"] = "c3:find",
  ["alt+f12"] = "c3:find_exactly",
}
