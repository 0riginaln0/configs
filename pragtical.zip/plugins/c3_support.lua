-- mod-version:3
local core = require "core"
local command = require "core.command"
local keymap = require "core.keymap"

local function regex_fn_macro(word)
  return "(fn|macro).* "..word
end

local function regex_const_alias_typedef_constdef_faultdef(word)
  local part1 = "(const|alias|typedef|constdef).* "..word
  local part2 = word.."(?= (?![:~])|,|;)"
  return part1.."|"..part2
end

local function regex_struct_union_interface_enum_bitstruct(word)
  return "(struct|union|interface|enum|bitstruct)\\s+"..word
end

local function regex_module(word)
  return "module.*\\b"..word.."\\b(?!::).*;"
end

local function find_x(dv, regex_builder)
  ---@cast dv core.docview
  command.perform "doc:select-word"
  local word = dv.doc:get_selection_text(1)
  local regex_query = regex_builder(word)
  
  -- open global search
  command.perform "project-search:find"
  
  -- get a reference to the current view
  ---@type core.view | widget
  local current_view = core.active_view
  core.add_thread(function()
    -- wait until project search becomes active active
    while not current_view.parent do
      coroutine.yield()
      current_view = core.active_view
    end
    ---@type plugins.projectsearch.resultsview
    local search_view = current_view.parent -- this holds the ref to searchview
    search_view.regex_toggle:set_toggle(true)
    search_view.find_text:set_text(regex_query)
    search_view.sensitive_toggle:set_toggle(true)
  end)
end

command.add("core.docview", {  
  ["c3:find_fn_macro"] = function(dv)
    find_x(dv, regex_fn_macro)
  end,

  ["c3:find_const_alias_typedef_constdef_faultdef"] = function(dv)
    find_x(dv, regex_const_alias_typedef_constdef_faultdef)
  end,

  ["c3:find_struct_union_interface_enum_bitstruct"] = function(dv)
    find_x(dv, regex_struct_union_interface_enum_bitstruct)
  end,

  ["c3:find_module"] = function(dv)
    find_x(dv, regex_module)
  end,
})

keymap.add {
  ["f12"] = "c3:find_fn_macro",
  ["alt+f12"] = "c3:find_const_alias_typedef_constdef_faultdef",
  ["ctrl+f12"] = "c3:find_struct_union_interface_enum_bitstruct",
  ["ctrl+shift+f12"] = "c3:find_module",
}
