-- mod-version:3
local core = require "core"
local command = require "core.command"
local keymap = require "core.keymap"

-- NOTES:
--   alias and fn are colliding a bit. Maybe separate fn+macro and const+alias+typedef

local function fn_macro_const_alias_typedef_constdef_regex(word)
  return "(fn|macro|const|alias|typedef|constdef).* "..word
end

local function module_regex(word)
  return "module.*\\b"..word.."\\b(?!::).*;"
end

local function struct_union_interface_enum_bitstruct_regex(word)
  return "(struct|union|interface|enum|bitstruct)\\s+"..word
end

local function faultdef_regex(word)
  return word.."(?= (?![:~])|,|;)"
end

local function find_x(dv, regex_builder)
  ---@cast dv core.docview
  command.perform "doc:select-word"
  local word = dv.doc:get_selection_text(1)
  local regex_query = regex_builder(word)
  
  -- open global search
  command.perform "project-search:find"
  
  -- get a reference to the current view
  ---@type core.view | widget
  local current_view = core.active_view
  core.add_thread(function()
    -- wait until project search becomes active active
    while not current_view.parent do
      coroutine.yield()
      current_view = core.active_view
    end
    ---@type plugins.projectsearch.resultsview
    local search_view = current_view.parent -- this holds the ref to searchview
    search_view.regex_toggle:set_toggle(true)
    search_view.find_text:set_text(regex_query)
    search_view.sensitive_toggle:set_toggle(true)
  end)
end

command.add("core.docview", {
  ["c3:find_definition"] = function(dv)
    find_x(dv, fn_macro_const_alias_typedef_constdef_regex)
  end,

  ["c3:find_module_definitions"] = function(dv)
    find_x(dv, module_regex)
  end,

  ["c3:find_struct_definitions"] = function(dv)
    find_x(dv, struct_union_interface_enum_bitstruct_regex)
  end,

  ["c3:find_faultdef"] = function(dv)
    find_x(dv, faultdef_regex)
  end,
})

keymap.add {
  ["f12"] = "c3:find_definition",
  ["alt+f12"] = "c3:find_module_definitions",
  ["ctrl+f12"] = "c3:find_struct_definitions",
  ["alt+ctrl+f12"] = "c3:find_faultdef",
}
