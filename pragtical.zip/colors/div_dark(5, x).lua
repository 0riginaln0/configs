-- dark
local style = require "core.style"
local common = require "core.common"

local NIGHT_MODE_INTENSITY = 0 -- [0, 1, ... 100]

local function clamp(min, max, value)
  return math.max(min, math.min(max, value))
end

local function hex_to_rgb(hex_str)
  local hex_str = hex_str:gsub("#", "")
  return tonumber("0x"..hex_str:sub(1,2)),
         tonumber("0x"..hex_str:sub(3,4)),
         tonumber("0x"..hex_str:sub(5,6))
end

local function rgb_to_hex(r, g, b)
  return string.format("#%02x%02x%02x", r, g, b)
end

local function hex_lightness(hex_str, on)
  local r, g, b = hex_to_rgb(hex_str)
  r = clamp(0, 255, r + on)
  g = clamp(0, 255, g + on)
  b = clamp(0, 255, b + on)
  return rgb_to_hex(r, g, b)
end

-- taken from https://tannerhelland.com/2012/09/18/convert-temperature-rgb-algorithm-code.html
local function kelvin_to_rgb(kelvin)
  local temp = clamp(1000, 40000, kelvin) / 100
  
  local r, g, b
  
  if temp <= 66 then
    r = 1.0
  else
    r = temp - 60
    r = 329.698727446 * (r ^ -0.1332047592)
  end
  
  if temp <= 66 then
    g = temp
    g = 99.4708025861 * math.log(g) - 161.1195636625
  else
    g = temp - 60
    g = 288.1221695283 * (g ^ -0.0755148492)
  end

  if temp >= 66 then
    b = 1.0
  elseif temp <= 19 then
    b = 0.0
  else
    b = temp - 10
    b = 138.5177312231 * math.log(b) - 305.0447927307
  end
  
  return clamp(0, 255, r),
         clamp(0, 255, g),
         clamp(0, 255, b)
end

local function apply_night_mode(hex_color, intensity_percent)
  local intensity = clamp(0, 100, intensity_percent) / 100
  local target_kelvin = 6500 - (intensity * (6500 - 1200))

  local night_r, night_g, night_b = kelvin_to_rgb(target_kelvin)
  local r, g, b = hex_to_rgb(hex_color)
  local base_r, base_g, base_b = kelvin_to_rgb(6500)
  
  local r_new = clamp(0, 255, math.floor(r * (night_r / base_r)))
  local g_new = clamp(0, 255, math.floor(g * (night_g / base_g)))
  local b_new = clamp(0, 255, math.floor(b * (night_b / base_b)))

  return rgb_to_hex(r_new, g_new, b_new)
end

local function get_colors(intensity)
  intensity = intensity or 0
  local function C(hex) return apply_night_mode(hex, intensity) end

  return {
    doc_background   = C(hex_lightness("#0E0E18", 10)), -- code background
    doc_gray_lighter = C(hex_lightness("#0E0E18", 30)), -- editor background, line with cursor on it
    doc_gray_light   = C("#48484f"), -- selection, line_guide
    doc_gray         = C("#b0b0b0"), -- scrollbar
    doc_gray_dark    = C("#999999"), -- line number, line_guide_highlight, scrollbar hovered
    doc_gray_darker  = C("#C9C9C9"), -- line number with cursor on line
    purple_light     = C("#6a5acd"), -- search selection result

    just_black     = C("#fafaff"), -- normal, symbol
    comment_gray   = C("#9E9E9E"), -- comments
    keyword_purple = C("#FEA3E2"), -- keywords
    keyword_red    = C("#ff8390"), -- other keywords #ff8390 #FF6D7C
    literal_bronze = C("#FFA94D"), -- numbers, literals
    string_gold    = C("#f7c95c"), -- strings
    just_blue      = C("#96d1ff"), -- operators, functions
  }
end

local c = get_colors(NIGHT_MODE_INTENSITY)

style.background       = { common.color(c.doc_background) }  -- Docview
style.background2      = { common.color(c.doc_gray_lighter) } -- Treeview
style.background3      = { common.color(c.doc_gray_lighter) } -- Command view
style.text             = { common.color(c.just_black) }
style.caret            = { common.color(c.just_blue) }
style.accent           = { common.color(c.just_blue) }
-- style.dim - text color for nonactive tabs, tabs divider, prefix in log and
-- search result, hotkeys for context menu and command view
style.dim              = { common.color(hex_lightness(c.just_black, -50)) } -- #ADADB3
style.divider          = { common.color(hex_lightness("#d0d0d0", -150)) } -- Line between nodes
style.selection        = { common.color(c.doc_gray_light) }
style.line_number      = { common.color(hex_lightness(c.doc_gray_darker, -70)) }
style.line_number2     = { common.color(c.doc_gray_darker) } -- With cursor
style.line_highlight   = { common.color(c.doc_gray_lighter) }
style.scrollbar        = { common.color(hex_lightness(c.doc_gray_darker, -130)) }
style.scrollbar2       = { common.color(hex_lightness(c.doc_gray_darker, -115)) } -- Hovered
style.scrollbar_track  = { common.color(c.doc_gray_lighter) }
style.nagbar           = { common.color "#FF0000" }
style.nagbar_text      = { common.color "#FFFFFF" }
style.nagbar_dim       = { common.color "rgba(0, 0, 0, 0.45)" }
style.drag_overlay     = { common.color "rgba(255, 255, 255,0.1)" }
style.drag_overlay_tab = { common.color(c.just_blue) }
style.good             = { common.color "#72b886" }
style.warn             = { common.color "#FFA94D" }
style.error            = { common.color "#FF3333" }
style.modified         = { common.color "#1c7c9c" }

-- For the indentguide.lua
style.guide           = { common.color "#48484f" }
style.guide_highlight = { common.color "#a1a1a6" }

style.search_selection      = { common.color(c.purple_light) }
style.search_selection_text = { common.color "#ffffff" }

style.syntax["normal"]   = { common.color(c.just_black) }
style.syntax["symbol"]   = { common.color(c.just_black) }
style.syntax["comment"]  = { common.color(c.comment_gray) }
style.syntax["keyword"]  = { common.color(c.keyword_purple) }  -- local function end if case
style.syntax["keyword2"] = { common.color(c.keyword_red) } -- self int float
style.syntax["number"]   = { common.color(c.literal_bronze) }
style.syntax["literal"]  = { common.color(c.literal_bronze) }  -- true false nil
style.syntax["string"]   = { common.color(c.string_gold) }
style.syntax["operator"] = { common.color(c.just_blue) } -- = + - / < >
style.syntax["function"] = { common.color(c.just_blue) }

style.log["INFO"]  = { icon = "i", color = style.text }
style.log["WARN"]  = { icon = "!", color = style.warn }
style.log["ERROR"] = { icon = "!", color = style.error }

return style
